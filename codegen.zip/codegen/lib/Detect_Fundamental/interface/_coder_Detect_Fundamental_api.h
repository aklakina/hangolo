//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: _coder_Detect_Fundamental_api.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

#ifndef _CODER_DETECT_FUNDAMENTAL_API_H
#define _CODER_DETECT_FUNDAMENTAL_API_H

// Include Files
#include "coder_array_mex.h"
#include "emlrt.h"
#include "tmwtypes.h"
#include <algorithm>
#include <cstring>

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

// Function Declarations
real_T Detect_Fundamental(coder::array<real_T, 1U> *inputData,
                          real_T SampleFrequency);

void Detect_Fundamental_api(const mxArray *const prhs[2], const mxArray **plhs);

void Detect_Fundamental_atexit();

void Detect_Fundamental_initialize();

void Detect_Fundamental_terminate();

void Detect_Fundamental_xil_shutdown();

void Detect_Fundamental_xil_terminate();

#endif
//
// File trailer for _coder_Detect_Fundamental_api.h
//
// [EOF]
//
