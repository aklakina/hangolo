//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: Detect_Fundamental_data.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

// Include Files
#include "Detect_Fundamental_data.h"
#include "rt_nonfinite.h"

//
// File trailer for Detect_Fundamental_data.cpp
//
// [EOF]
//
