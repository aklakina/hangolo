//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: fft.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

// Include Files
#include "fft.h"
#include "FFTImplementationCallback.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
//
// Arguments    : const ::coder::array<double, 1U> &x
//                double varargin_1
//                ::coder::array<creal_T, 1U> &y
// Return Type  : void
//
namespace coder {
void fft(const ::coder::array<double, 1U> &x, double varargin_1,
         ::coder::array<creal_T, 1U> &y)
{
  array<double, 2U> costab;
  array<double, 2U> costab1q;
  array<double, 2U> sintab;
  array<double, 2U> sintabinv;
  if ((x.size(0) == 0) || (0 == static_cast<int>(varargin_1))) {
    int pmax;
    pmax = static_cast<int>(varargin_1);
    y.set_size(pmax);
    for (int pow2p{0}; pow2p < pmax; pow2p++) {
      y[pow2p].re = 0.0;
      y[pow2p].im = 0.0;
    }
  } else {
    double twid_re;
    int j;
    int k;
    int pmax;
    int pmin;
    int pow2p;
    boolean_T useRadix2;
    useRadix2 = ((static_cast<int>(varargin_1) > 0) &&
                 ((static_cast<int>(varargin_1) &
                   (static_cast<int>(varargin_1) - 1)) == 0));
    pmin = 1;
    if (useRadix2) {
      pmax = static_cast<int>(varargin_1);
    } else {
      if (static_cast<int>(varargin_1) > 0) {
        j = (static_cast<int>(varargin_1) + static_cast<int>(varargin_1)) - 1;
        pmax = 31;
        if (j <= 1) {
          pmax = 0;
        } else {
          boolean_T exitg1;
          pmin = 0;
          exitg1 = false;
          while ((!exitg1) && (pmax - pmin > 1)) {
            k = (pmin + pmax) >> 1;
            pow2p = 1 << k;
            if (pow2p == j) {
              pmax = k;
              exitg1 = true;
            } else if (pow2p > j) {
              pmax = k;
            } else {
              pmin = k;
            }
          }
        }
        pmin = 1 << pmax;
      }
      pmax = pmin;
    }
    twid_re = 6.2831853071795862 / static_cast<double>(pmax);
    j = pmax / 2 / 2;
    costab1q.set_size(1, j + 1);
    costab1q[0] = 1.0;
    pmax = j / 2 - 1;
    for (k = 0; k <= pmax; k++) {
      costab1q[k + 1] = std::cos(twid_re * (static_cast<double>(k) + 1.0));
    }
    pow2p = pmax + 2;
    pmax = j - 1;
    for (k = pow2p; k <= pmax; k++) {
      costab1q[k] = std::sin(twid_re * static_cast<double>(j - k));
    }
    costab1q[j] = 0.0;
    if (!useRadix2) {
      j = costab1q.size(1) - 1;
      pmax = (costab1q.size(1) - 1) << 1;
      costab.set_size(1, pmax + 1);
      sintab.set_size(1, pmax + 1);
      costab[0] = 1.0;
      sintab[0] = 0.0;
      sintabinv.set_size(1, pmax + 1);
      for (k = 0; k < j; k++) {
        sintabinv[k + 1] = costab1q[(j - k) - 1];
      }
      pow2p = costab1q.size(1);
      for (k = pow2p; k <= pmax; k++) {
        sintabinv[k] = costab1q[k - j];
      }
      for (k = 0; k < j; k++) {
        costab[k + 1] = costab1q[k + 1];
        sintab[k + 1] = -costab1q[(j - k) - 1];
      }
      pow2p = costab1q.size(1);
      for (k = pow2p; k <= pmax; k++) {
        costab[k] = -costab1q[pmax - k];
        sintab[k] = -costab1q[k - j];
      }
    } else {
      j = costab1q.size(1) - 1;
      pmax = (costab1q.size(1) - 1) << 1;
      costab.set_size(1, pmax + 1);
      sintab.set_size(1, pmax + 1);
      costab[0] = 1.0;
      sintab[0] = 0.0;
      for (k = 0; k < j; k++) {
        costab[k + 1] = costab1q[k + 1];
        sintab[k + 1] = -costab1q[(j - k) - 1];
      }
      pow2p = costab1q.size(1);
      for (k = pow2p; k <= pmax; k++) {
        costab[k] = -costab1q[pmax - k];
        sintab[k] = -costab1q[k - j];
      }
      sintabinv.set_size(1, 0);
    }
    if (useRadix2) {
      y.set_size(static_cast<int>(varargin_1));
      if (static_cast<int>(varargin_1) > x.size(0)) {
        y.set_size(static_cast<int>(varargin_1));
        pmax = static_cast<int>(varargin_1);
        for (pow2p = 0; pow2p < pmax; pow2p++) {
          y[pow2p].re = 0.0;
          y[pow2p].im = 0.0;
        }
      }
      if (static_cast<int>(varargin_1) != 1) {
        internal::fft::FFTImplementationCallback::doHalfLengthRadix2(
            x, y, static_cast<int>(varargin_1), costab, sintab);
      } else {
        double temp_im;
        double temp_re;
        double twid_im;
        int i;
        int istart;
        int nRowsD2;
        pmax = x.size(0);
        istart = static_cast<int>(varargin_1);
        if (pmax < istart) {
          istart = pmax;
        }
        pmin = static_cast<int>(varargin_1) - 2;
        nRowsD2 = static_cast<int>(varargin_1) / 2;
        k = nRowsD2 / 2;
        pmax = 0;
        pow2p = 0;
        for (i = 0; i <= istart - 2; i++) {
          y[pmax].re = x[i];
          y[pmax].im = 0.0;
          j = static_cast<int>(varargin_1);
          useRadix2 = true;
          while (useRadix2) {
            j >>= 1;
            pow2p ^= j;
            useRadix2 = ((pow2p & j) == 0);
          }
          pmax = pow2p;
        }
        y[pmax].re = x[istart - 1];
        y[pmax].im = 0.0;
        if (static_cast<int>(varargin_1) > 1) {
          for (i = 0; i <= pmin; i += 2) {
            temp_re = y[i + 1].re;
            temp_im = y[i + 1].im;
            twid_re = y[i].re;
            twid_im = y[i].im;
            y[i + 1].re = y[i].re - y[i + 1].re;
            y[i + 1].im = y[i].im - y[i + 1].im;
            twid_re += temp_re;
            twid_im += temp_im;
            y[i].re = twid_re;
            y[i].im = twid_im;
          }
        }
        pmax = 2;
        pmin = 4;
        pow2p = ((k - 1) << 2) + 1;
        while (k > 0) {
          int temp_re_tmp;
          for (i = 0; i < pow2p; i += pmin) {
            temp_re_tmp = i + pmax;
            temp_re = y[temp_re_tmp].re;
            temp_im = y[temp_re_tmp].im;
            y[temp_re_tmp].re = y[i].re - temp_re;
            y[temp_re_tmp].im = y[i].im - temp_im;
            y[i].re = y[i].re + temp_re;
            y[i].im = y[i].im + temp_im;
          }
          istart = 1;
          for (j = k; j < nRowsD2; j += k) {
            int ihi;
            twid_re = costab[j];
            twid_im = sintab[j];
            i = istart;
            ihi = istart + pow2p;
            while (i < ihi) {
              temp_re_tmp = i + pmax;
              temp_re =
                  twid_re * y[temp_re_tmp].re - twid_im * y[temp_re_tmp].im;
              temp_im =
                  twid_re * y[temp_re_tmp].im + twid_im * y[temp_re_tmp].re;
              y[temp_re_tmp].re = y[i].re - temp_re;
              y[temp_re_tmp].im = y[i].im - temp_im;
              y[i].re = y[i].re + temp_re;
              y[i].im = y[i].im + temp_im;
              i += pmin;
            }
            istart++;
          }
          k /= 2;
          pmax = pmin;
          pmin += pmin;
          pow2p -= pmax;
        }
      }
    } else {
      internal::fft::FFTImplementationCallback::dobluesteinfft(
          x, pmin, static_cast<int>(varargin_1), costab, sintab, sintabinv, y);
    }
  }
}

} // namespace coder

//
// File trailer for fft.cpp
//
// [EOF]
//
