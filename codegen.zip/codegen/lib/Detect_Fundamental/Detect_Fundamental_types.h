//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: Detect_Fundamental_types.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

#ifndef DETECT_FUNDAMENTAL_TYPES_H
#define DETECT_FUNDAMENTAL_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for Detect_Fundamental_types.h
//
// [EOF]
//
