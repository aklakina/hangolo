//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: levi.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

#ifndef LEVI_H
#define LEVI_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
class levi {
public:
  levi();
  ~levi();
  double Detect_Fundamental(const coder::array<double, 1U> &inputData,
                            double SampleFrequency);
};

#endif
//
// File trailer for levi.h
//
// [EOF]
//
