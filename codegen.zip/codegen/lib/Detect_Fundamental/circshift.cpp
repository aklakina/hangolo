//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: circshift.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

// Include Files
#include "circshift.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : int a[2]
//                int p
// Return Type  : void
//
namespace coder {
void circshift(int a[2], int p)
{
  if (p < 0) {
    int a__1;
    a__1 = a[0];
    a[0] = 1;
    a[1] = a__1;
  }
}

} // namespace coder

//
// File trailer for circshift.cpp
//
// [EOF]
//
