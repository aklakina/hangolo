//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: levi.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 13-Jun-2021 16:47:49
//

// Include Files
#include "levi.h"
#include "circshift.h"
#include "fft.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <math.h>

// Function Declarations
static int div_s32_floor(int numerator, int denominator);

static double rt_hypotd_snf(double u0, double u1);

static double rt_powd_snf(double u0, double u1);

// Function Definitions
//
// Arguments    : int numerator
//                int denominator
// Return Type  : int
//
static int div_s32_floor(int numerator, int denominator)
{
  int quotient;
  if (denominator == 0) {
    if (numerator >= 0) {
      quotient = MAX_int32_T;
    } else {
      quotient = MIN_int32_T;
    }
  } else {
    unsigned int absDenominator;
    unsigned int absNumerator;
    unsigned int tempAbsQuotient;
    boolean_T quotientNeedsNegation;
    if (numerator < 0) {
      absNumerator = ~static_cast<unsigned int>(numerator) + 1U;
    } else {
      absNumerator = static_cast<unsigned int>(numerator);
    }
    if (denominator < 0) {
      absDenominator = ~static_cast<unsigned int>(denominator) + 1U;
    } else {
      absDenominator = static_cast<unsigned int>(denominator);
    }
    quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
    tempAbsQuotient = absNumerator / absDenominator;
    if (quotientNeedsNegation) {
      absNumerator %= absDenominator;
      if (absNumerator > 0U) {
        tempAbsQuotient++;
      }
      quotient = -static_cast<int>(tempAbsQuotient);
    } else {
      quotient = static_cast<int>(tempAbsQuotient);
    }
  }
  return quotient;
}

//
// Arguments    : double u0
//                double u1
// Return Type  : double
//
static double rt_hypotd_snf(double u0, double u1)
{
  double a;
  double y;
  a = std::abs(u0);
  y = std::abs(u1);
  if (a < y) {
    a /= y;
    y *= std::sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = a * std::sqrt(y * y + 1.0);
  } else if (!std::isnan(y)) {
    y = a * 1.4142135623730951;
  }
  return y;
}

//
// Arguments    : double u0
//                double u1
// Return Type  : double
//
static double rt_powd_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = rtNaN;
  } else {
    double d;
    double d1;
    d = std::abs(u0);
    d1 = std::abs(u1);
    if (std::isinf(u1)) {
      if (d == 1.0) {
        y = 1.0;
      } else if (d > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = rtNaN;
    } else {
      y = std::pow(u0, u1);
    }
  }
  return y;
}

//
// Arguments    : const coder::array<double, 1U> &inputData
//                double SampleFrequency
// Return Type  : double
//
double levi::Detect_Fundamental(const coder::array<double, 1U> &inputData,
                                double SampleFrequency)
{
  coder::array<creal_T, 1U> x;
  coder::array<double, 2U> Fv;
  coder::array<double, 2U> HPS;
  coder::array<double, 2U> c_y0;
  coder::array<double, 2U> hps3;
  coder::array<double, 2U> hps4;
  coder::array<double, 2U> hps5;
  coder::array<double, 1U> b_y0;
  double delta1;
  double n;
  int b_lshift[2];
  int c_lshift[2];
  int lshift[2];
  int sizeX[2];
  int b_i;
  int b_lshift_idx_0;
  int i;
  int i1;
  int i2;
  int i3;
  int i4;
  int k;
  int lshift_idx_0;
  int nx;
  unsigned int u;
  n = frexp(static_cast<double>(inputData.size(0)), &nx);
  if (n == 0.5) {
    nx--;
  }
  n = rt_powd_snf(2.0, static_cast<double>(nx));
  u = static_cast<unsigned int>(std::trunc(n / 2.0));
  Fv.set_size(1, static_cast<int>(u));
  if (static_cast<int>(u) >= 1) {
    Fv[static_cast<int>(u) - 1] = 1.0;
    if (Fv.size(1) >= 2) {
      Fv[0] = 0.0;
      if (Fv.size(1) >= 3) {
        delta1 = 1.0 / (static_cast<double>(Fv.size(1)) - 1.0);
        i = Fv.size(1);
        for (k = 0; k <= i - 3; k++) {
          Fv[k + 1] = (static_cast<double>(k) + 1.0) * delta1;
        }
      }
    }
  }
  Fv.set_size(1, Fv.size(1));
  nx = Fv.size(1) - 1;
  for (i = 0; i <= nx; i++) {
    Fv[i] = Fv[i] * SampleFrequency / 2.0;
  }
  coder::fft(inputData, n, x);
  nx = x.size(0);
  b_y0.set_size(x.size(0));
  for (k = 0; k < nx; k++) {
    b_y0[k] = rt_hypotd_snf(x[k].re, x[k].im);
  }
  nx = b_y0.size(0);
  for (i = 0; i < nx; i++) {
    b_y0[i] = b_y0[i] / n;
  }
  nx = 2;
  if (b_y0.size(0) != 1) {
    nx = 1;
  }
  lshift[0] = b_y0.size(0);
  lshift[1] = 1;
  coder::circshift(lshift, 1 - nx);
  if (1 > lshift[0]) {
    i = 0;
  } else {
    i = lshift[0];
  }
  nx = 2;
  if (b_y0.size(0) != 1) {
    nx = 1;
  }
  b_lshift[0] = b_y0.size(0);
  b_lshift[1] = 1;
  coder::circshift(b_lshift, 1 - nx);
  if (1 > b_lshift[0]) {
    i1 = 1;
    i2 = -1;
  } else {
    i1 = 2;
    i2 = b_lshift[0] - 1;
  }
  nx = 1;
  if (b_y0.size(0) != 1) {
    nx = 0;
  }
  sizeX[0] = b_y0.size(0);
  sizeX[1] = 1;
  c_lshift[0] = b_y0.size(0);
  c_lshift[1] = 1;
  coder::circshift(c_lshift, -nx);
  if (1 > c_lshift[0]) {
    i3 = 1;
    i4 = -1;
  } else {
    i3 = 3;
    i4 = c_lshift[0] - 1;
  }
  k = div_s32_floor(i4, i3);
  sizeX[nx] = k + 1;
  lshift_idx_0 = c_lshift[0];
  nx = c_lshift[1];
  c_y0.set_size(k + 1, c_lshift[1]);
  for (i4 = 0; i4 < nx; i4++) {
    for (b_i = 0; b_i <= k; b_i++) {
      c_y0[b_i + c_y0.size(0) * i4] = b_y0[i3 * b_i + lshift_idx_0 * i4];
    }
  }
  hps3.set_size(sizeX[0], sizeX[1]);
  nx = sizeX[0] * sizeX[1];
  for (i3 = 0; i3 < nx; i3++) {
    hps3[i3] = c_y0[i3];
  }
  nx = 1;
  if (b_y0.size(0) != 1) {
    nx = 0;
  }
  sizeX[0] = b_y0.size(0);
  sizeX[1] = 1;
  c_lshift[0] = b_y0.size(0);
  c_lshift[1] = 1;
  coder::circshift(c_lshift, -nx);
  if (1 > c_lshift[0]) {
    i3 = 1;
    i4 = -1;
  } else {
    i3 = 4;
    i4 = c_lshift[0] - 1;
  }
  k = div_s32_floor(i4, i3);
  sizeX[nx] = k + 1;
  lshift_idx_0 = c_lshift[0];
  nx = c_lshift[1];
  c_y0.set_size(k + 1, c_lshift[1]);
  for (i4 = 0; i4 < nx; i4++) {
    for (b_i = 0; b_i <= k; b_i++) {
      c_y0[b_i + c_y0.size(0) * i4] = b_y0[i3 * b_i + lshift_idx_0 * i4];
    }
  }
  hps4.set_size(sizeX[0], sizeX[1]);
  nx = sizeX[0] * sizeX[1];
  for (i3 = 0; i3 < nx; i3++) {
    hps4[i3] = c_y0[i3];
  }
  nx = 1;
  if (b_y0.size(0) != 1) {
    nx = 0;
  }
  sizeX[0] = b_y0.size(0);
  sizeX[1] = 1;
  c_lshift[0] = b_y0.size(0);
  c_lshift[1] = 1;
  coder::circshift(c_lshift, -nx);
  if (1 > c_lshift[0]) {
    i3 = 1;
    i4 = -1;
  } else {
    i3 = 5;
    i4 = c_lshift[0] - 1;
  }
  k = div_s32_floor(i4, i3);
  sizeX[nx] = k + 1;
  lshift_idx_0 = c_lshift[0];
  nx = c_lshift[1];
  c_y0.set_size(k + 1, c_lshift[1]);
  for (i4 = 0; i4 < nx; i4++) {
    for (b_i = 0; b_i <= k; b_i++) {
      c_y0[b_i + c_y0.size(0) * i4] = b_y0[i3 * b_i + lshift_idx_0 * i4];
    }
  }
  lshift_idx_0 = sizeX[0];
  hps5.set_size(sizeX[0], sizeX[1]);
  nx = sizeX[0] * sizeX[1];
  for (i3 = 0; i3 < nx; i3++) {
    hps5[i3] = c_y0[i3];
  }
  if ((hps5.size(0) == 0) || (hps5.size(1) == 0)) {
    k = 0;
  } else {
    nx = hps5.size(0);
    k = hps5.size(1);
    if (nx > k) {
      k = nx;
    }
  }
  HPS.set_size(1, k);
  for (i3 = 0; i3 < k; i3++) {
    HPS[i3] = 0.0;
  }
  if ((hps5.size(0) == 0) || (hps5.size(1) == 0)) {
    k = 0;
  } else {
    nx = hps5.size(0);
    k = hps5.size(1);
    if (nx > k) {
      k = nx;
    }
    lshift_idx_0 = lshift[0];
    b_lshift_idx_0 = b_lshift[0];
  }
  for (b_i = 0; b_i < k; b_i++) {
    nx = div_s32_floor(i2, i1) + 1;
    HPS[b_i] = b_y0[b_i % i + lshift_idx_0 * (b_i / i)] *
               b_y0[i1 * (b_i % nx) + b_lshift_idx_0 * (b_i / nx)] * hps3[b_i] *
               hps4[b_i] * hps5[b_i];
  }
  nx = HPS.size(1);
  if (HPS.size(1) <= 2) {
    if (HPS.size(1) == 1) {
      b_i = 1;
    } else if ((HPS[0] < HPS[HPS.size(1) - 1]) ||
               (std::isnan(HPS[0]) && (!std::isnan(HPS[HPS.size(1) - 1])))) {
      b_i = HPS.size(1);
    } else {
      b_i = 1;
    }
  } else {
    if (!std::isnan(HPS[0])) {
      b_i = 1;
    } else {
      boolean_T exitg1;
      b_i = 0;
      k = 2;
      exitg1 = false;
      while ((!exitg1) && (k <= nx)) {
        if (!std::isnan(HPS[k - 1])) {
          b_i = k;
          exitg1 = true;
        } else {
          k++;
        }
      }
    }
    if (b_i == 0) {
      b_i = 1;
    } else {
      n = HPS[b_i - 1];
      i = b_i + 1;
      for (k = i; k <= nx; k++) {
        delta1 = HPS[k - 1];
        if (n < delta1) {
          n = delta1;
          b_i = k;
        }
      }
    }
  }
  return Fv[b_i - 1];
}

//
// Arguments    : void
// Return Type  : void
//
levi::levi()
{
}

//
// Arguments    : void
// Return Type  : void
//
levi::~levi()
{
  // (no terminate code required)
}

//
// File trailer for levi.cpp
//
// [EOF]
//
