#include "fft.h"
#include "FFTRealFixLen.h"

class FFTRealWrapperPrivate {
public:
    FFTRealFixLen<FFTLengthPowerOfTwo> m_fft;
};

Fft::Fft():
    m_private(new FFTRealWrapperPrivate)
{

}

Fft::~Fft()
{
    delete m_private;
}

void Fft::calculateFFT(DataType in[], const DataType out[])
{
    m_private->m_fft.do_fft(in, out);
}
