#ifndef FFT_H
#define FFT_H

#include "fft_global.h"

class FFTRealWrapperPrivate;
static const int FFTLengthPowerOfTwo = 12;


class FFT_EXPORT Fft
{
public:
    Fft();
    ~Fft();
    typedef float DataType;
    void calculateFFT(DataType in[], const DataType out[]);

private:
    FFTRealWrapperPrivate* m_private;
};
#endif // FFT_H
