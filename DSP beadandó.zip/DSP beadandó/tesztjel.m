%%
 clear all;
 close all;
 rng default;
f0=110;
fs = 50000;
sec =3;
Amp = 4;
t =linspace(0,sec,fs*sec+1);
%t = 0:1/fs:sec-1/fs;
%x = Amp*(sin(2*pi*f0*t))+0.1*randn(size(t));
x = Amp*(square(2*pi*f0*t));
%% 
y=fft(x);
y0=fftshift(y);
n = length(x);
%freq1 = (0:n-1)*(fs/n);
freq = (-n/2:n/2-1)*(fs/n);
magndb = 10*log10(abs(y0)/n);
figure;
plot(freq,magndb,'b');
%%
n = length(x);
Fv = linspace(0, 1, fix(n/2)+1)*fs/2;
Iv = 1:length(Fv);
magndb = 10*log10(abs(y)/n);
mv = magndb(Iv);
figure;
plot(Fv,mv,'b');
%%
[pxx,f]= pwelch(x,[],[],[],fs);
[pxx,f] = pwelch(x,500,300,500,fs);
db = pow2db(pxx);
figure;
plot(f,db);
%%
fb=fft(sigsound);
nb = length(sigsound);
freqb = (0:nb-1)*(Fs/nb);
magndbb = 10*log10(abs(sigsound)/nb);
figure;
plot(freqb,abs(fb),'b');
%%
[pxxb,fb]= pwelch(sigsound,[],[],[],Fs);

dbb = pow2db(pxxb);
figure;
hold on;
 [maxval,idx] = max(dbb);
    fb(idx)
plot(fb,dbb);
%%
% [sigsound, Fs] = audioread('E4.wav');
n = length(sigsound);
Fv = linspace(0, 1, fix(n/2)+1)*Fs/2;
Iv = 1:length(Fv);
magndb = 10*log10(abs(fft(sigsound))/n);
mv = magndb(Iv);
 [maxval,idx] = max(mv);
    Fv(idx)

figure;
plot(Fv,mv,'b');