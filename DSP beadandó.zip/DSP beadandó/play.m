 sigsound = getaudiodata(a);
%   player = audioplayer(sigsound,Fs);
%   player.play;
%   c =xcorr(sigsound);
% 
